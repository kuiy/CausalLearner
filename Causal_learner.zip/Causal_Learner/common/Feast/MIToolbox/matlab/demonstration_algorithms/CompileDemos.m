 mex -I../../ mRMR_D_Mex.c ../../src/MutualInformation.c ../../src/ArrayOperations.c ../../src/CalculateProbability.c ../../src/Entropy.c
 mex -I../../ DISR_Mex.c ../../src/MutualInformation.c ../../src/ArrayOperations.c ../../src/CalculateProbability.c ../../src/Entropy.c
 mex -I../../ CMIM_Mex.c ../../src/MutualInformation.c ../../src/ArrayOperations.c ../../src/CalculateProbability.c ../../src/Entropy.c
